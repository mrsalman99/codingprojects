package com.example.salmanrps

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random

class MainActivity : AppCompatActivity()
{
    var youscore : Int = 0
    var aiscore : Int = 0
    private var currentToast: Toast? = null
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        fun showToast(message:String)
        {
            if (currentToast != null) {
                currentToast?.cancel()
            }
            val inflater = LayoutInflater.from(this)
            val layout = inflater.inflate(R.layout.customtoast,findViewById(R.id.maintoast))

            val toasttxt : TextView = layout.findViewById(R.id.mytoast)

            currentToast = Toast(this)
            currentToast?.duration = Toast.LENGTH_SHORT
            currentToast?.setGravity(Gravity.CENTER_VERTICAL, -20, 360)
            currentToast?.view = layout
            toasttxt.setText(message)
            currentToast?.show()
        }
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val rockbutton : Button = findViewById(R.id.rockbutton)
        val paperbutton : Button = findViewById(R.id.paperbutton)
        val scissorsbutton : Button = findViewById(R.id.scissorsbutton)
        val quit : Button = findViewById(R.id.quit)

        val aiimg : ImageView = findViewById(R.id.aiimg)
        val youimg : ImageView = findViewById(R.id.youimg)

        val aiscr : TextView = findViewById(R.id.aiscr)
        val youscr : TextView = findViewById(R.id.youscr)

        fun game(youturn: String) : String
        {
            var choice : String = ""
            val ainum = Random.nextInt(1,4)
            if(ainum == 1)
            {
                choice = "rock"
            }
            else if(ainum == 2)
            {
                choice = "paper"
            }
            else if(ainum == 3)
            {
                choice = "scissors"
            }
            if(choice == "rock")
            {
                aiimg.setImageResource(R.drawable.rock)
            }
            else if(choice == "paper")
            {
                aiimg.setImageResource(R.drawable.paper)
            }
            else if(choice == "scissors")
            {
                aiimg.setImageResource(R.drawable.scissors)
            }

            if(youturn == choice)
            {
                return "TIE!"
            }
            else if(youturn == "rock" && choice == "paper")
            {
                aiscore++
                return "AI won"
            }
            else if(youturn == "rock" && choice == "scissors")
            {
                youscore++
                return "You won"
            }
            else if(youturn == "scissors" && choice == "rock")
            {
                aiscore++
                return "AI won"
            }
            else if(youturn == "scissors" && choice == "paper")
            {
                youscore++
                return "You won"
            }
            else if(youturn == "paper" && choice == "rock")
            {
                youscore++
                return "You won"
            }
            else if(youturn == "paper" && choice == "scissors")
            {
                aiscore++
                return "AI won"
            }
            else return "null"
        }
        rockbutton.setOnClickListener(object : View.OnClickListener
        {
            override fun onClick(view: View)
            {
                youimg.setImageResource(R.drawable.rock)
                var message : String = game("rock")
                showToast(message)
                youscr.setText(Integer.toString(youscore))
                aiscr.setText(Integer.toString(aiscore))
            }
        })
        paperbutton.setOnClickListener(object : View.OnClickListener
        {
            override fun onClick(view: View)
            {
                youimg.setImageResource(R.drawable.paper)
                var message : String = game("paper")
                showToast(message)
                youscr.setText(Integer.toString(youscore))
                aiscr.setText(Integer.toString(aiscore))
            }
        })
        scissorsbutton.setOnClickListener(object : View.OnClickListener
        {
            override fun onClick(view: View)
            {
                youimg.setImageResource(R.drawable.scissors)
                var message : String = game("scissors")
                showToast(message)
                youscr.setText(Integer.toString(youscore))
                aiscr.setText(Integer.toString(aiscore))
            }
        })
        quit.setOnClickListener(object : View.OnClickListener
        {
            override fun onClick(view: View)
            {
                end()
            }
        })
    }
    fun end()
    {
        val intent = Intent(this,End::class.java)
        intent.putExtra("you",youscore)
        intent.putExtra("ai",aiscore)
        startActivity(intent)
    }
}