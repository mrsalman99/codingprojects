package com.example.salmanrps

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class End : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_end)

        val endai : TextView = findViewById(R.id.endai)
        val endyou : TextView = findViewById(R.id.endyou)
        val playagain : Button = findViewById(R.id.playagain)
        val mainmenu : Button = findViewById(R.id.mainmenu)

        val intent = getIntent()
        var aiscore = intent.extras?.getInt("ai")
        var youscore = intent.extras?.getInt("you")
        endyou.setText(youscore?.let { Integer.toString(it) })
        endai.setText(aiscore?.let { Integer.toString(it) })

        playagain.setOnClickListener(object : View.OnClickListener
        {
            override fun onClick(p0: View?)
            {
                play()
            }
        }
        )
        mainmenu.setOnClickListener(object : View.OnClickListener
        {
            override fun onClick(p0: View?)
            {
                goMain()
            }
        }
        )
    }
    fun play()
    {
        val intent = Intent(this,MainActivity::class.java)
        startActivity(intent)
    }
    fun goMain()
    {
        val intent = Intent(this,Start::class.java)
        startActivity(intent)
    }
}